module.exports = [
"[project]/.next-internal/server/app/api/config-crud/tables/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/fs/promises [external] (fs/promises, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs/promises", () => require("fs/promises"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[project]/app/api/config-crud/tables/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// app/api/config-crud/tables/route.ts
__turbopack_context__.s([
    "GET",
    ()=>GET,
    "runtime",
    ()=>runtime
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs$2f$promises__$5b$external$5d$__$28$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs/promises [external] (fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
const runtime = 'nodejs';
;
;
;
;
// --- paths ---
const ROOT = process.cwd();
const SCHEMA = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].resolve(ROOT, 'prisma/schema.prisma');
const OUT_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].resolve(ROOT, 'config/crud');
const OUT_CRUD = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(OUT_DIR, 'crudTable.json');
// --- helpers de lectura/escritura ---
function safeParse(raw, fallback) {
    try {
        return JSON.parse(raw);
    } catch  {
        return fallback;
    }
}
async function ensureOutDir() {
    await __TURBOPACK__imported__module__$5b$externals$5d2f$fs$2f$promises__$5b$external$5d$__$28$fs$2f$promises$2c$__cjs$29$__["default"].mkdir(OUT_DIR, {
        recursive: true
    });
}
function fileExists(p) {
    try {
        __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].accessSync(p);
        return true;
    } catch  {
        return false;
    }
}
// --- generador embebido (misma lógica del script) ---
function baseTypeFrom(token) {
    const t = token.replace('?', '').replace('[]', '');
    if ([
        'Int',
        'BigInt',
        'Float',
        'Decimal'
    ].includes(t)) return 'Number';
    if (t === 'Boolean') return 'Boolean';
    if (t === 'DateTime') return 'DateTime';
    return 'String';
}
function discoverCrudModels(schemaText) {
    const models = [];
    const lines = schemaText.split('\n');
    for(let i = 0; i < lines.length; i++){
        const line = lines[i].trim();
        if (line.startsWith('model ')) {
            const m = /^model\s+(\w+)\s*\{/.exec(line);
            if (!m) continue;
            const name = m[1];
            const window = lines.slice(Math.max(0, i - 5), i).join('\n');
            const hasCrudDoc = /\/\/\/\s*@crud/i.test(window);
            const hasPrefix = /^Crud/i.test(name);
            if (hasCrudDoc || hasPrefix) models.push(name);
        }
    }
    return models;
}
function parseModelFields(schemaText, model) {
    const re = new RegExp(`model\\s+${model}\\s*\\{([\\s\\S]*?)\\}`, 'm');
    const m = re.exec(schemaText);
    if (!m) return [];
    return m[1].split('\n').map((s)=>s.trim()).filter((s)=>s && !s.startsWith('//') && !s.startsWith('@@')).map((line)=>{
        const [name, typeToken] = line.split(/\s+/);
        const required = !/\?$/.test(typeToken || '');
        const base = baseTypeFrom(typeToken || 'String');
        return {
            key: name,
            type: base,
            required
        };
    }).filter((f)=>![
            'id',
            'createdAt',
            'updatedAt'
        ].includes(String(f.key)));
}
async function generateCrudTableJson() {
    const schema = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs$2f$promises__$5b$external$5d$__$28$fs$2f$promises$2c$__cjs$29$__["default"].readFile(SCHEMA, 'utf-8');
    const models = discoverCrudModels(schema);
    const out = {
        models: models.map((name)=>({
                name,
                fields: parseModelFields(schema, name).map((f)=>({
                        key: f.key,
                        type: f.type,
                        required: !!f.required
                    }))
            }))
    };
    await ensureOutDir();
    await __TURBOPACK__imported__module__$5b$externals$5d2f$fs$2f$promises__$5b$external$5d$__$28$fs$2f$promises$2c$__cjs$29$__["default"].writeFile(OUT_CRUD, JSON.stringify(out, null, 2));
    return out;
}
async function readCrudTable() {
    if (!fileExists(OUT_CRUD)) return {
        models: []
    };
    const raw = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs$2f$promises__$5b$external$5d$__$28$fs$2f$promises$2c$__cjs$29$__["default"].readFile(OUT_CRUD, 'utf-8');
    const json = safeParse(raw, {
        models: []
    });
    return json;
}
async function GET(req) {
    try {
        const { searchParams } = new URL(req.url);
        const run = searchParams.get('run');
        if (run === '1') {
            // ejecuta generador embebido
            await generateCrudTableJson();
        }
        const current = await readCrudTable();
        // La UI solo necesita { name }
        const list = Array.isArray(current.models) ? current.models.map((m)=>({
                name: m.name
            })) : [];
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            data: list
        });
    } catch (e) {
        console.error('[config-crud/tables] GET error:', e);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            data: []
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__ec47254e._.js.map