module.exports = [
"[project]/.next-internal/server/app/api/crud/[model]/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/@prisma/client [external] (@prisma/client, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("@prisma/client", () => require("@prisma/client"));

module.exports = mod;
}),
"[project]/lib/prisma.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// lib/prisma.ts (OK)
__turbopack_context__.s([
    "prisma",
    ()=>prisma
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/@prisma/client [external] (@prisma/client, cjs)");
;
const globalForPrisma = globalThis;
const prisma = globalForPrisma.prisma ?? new __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["PrismaClient"]({
    log: [
        "warn",
        "error"
    ]
});
if ("TURBOPACK compile-time truthy", 1) globalForPrisma.prisma = prisma;
}),
"[project]/infrastructure/dal.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// infrastructure/dal.ts
__turbopack_context__.s([
    "bulkDelete",
    ()=>bulkDelete,
    "count",
    ()=>count,
    "create",
    ()=>create,
    "existsByField",
    ()=>existsByField,
    "findMany",
    ()=>findMany,
    "findUnique",
    ()=>findUnique,
    "isValidModel",
    ()=>isValidModel,
    "keyFor",
    ()=>keyFor,
    "remove",
    ()=>remove,
    "update",
    ()=>update
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/prisma.ts [app-route] (ecmascript)");
;
const validModels = [
    "patient",
    "professional",
    "clinicalhistory",
    "appointment",
    "collection",
    "collectionfield"
];
function isValidModel(model) {
    return validModels.includes(model);
}
function keyFor(model) {
    const m = (model || "").toLowerCase();
    // Aliases/plurales comunes
    if (m === "patients") return "patient";
    if (m === "professionals") return "professional";
    if (m === "services") return "services";
    if (m === "clinicalhistory" || m === "clinicalhistories") return "clinicalHistory";
    if (m === "appointments") return "appointment";
    // ⚠️ Importante: no mapeamos a 'collectionField' porque ese delegate no existe
    // en tu Prisma actual. Si en el futuro agregas el modelo `CollectionField`,
    // tras migrar podrás añadir:
    // if (m === 'collectionfield' || m === 'collectionfields' || m === 'fields') return 'collectionField'
    // Fallback: intentamos el mismo nombre (ej. 'patient', 'professional', 'collection', 'appointment')
    return m;
}
/** Helper para obtener delegate con guardas */ function repoOf(model) {
    const key = keyFor(model);
    const repo = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"][key];
    if (!repo) {
        console.error(`[DAL] delegate no encontrado para modelo "${model}" (key "${String(key)}")`);
    }
    return repo;
}
async function findMany(model, params) {
    const repo = repoOf(model);
    if (!repo) return [];
    return repo.findMany(params);
}
async function count(model, where) {
    const repo = repoOf(model);
    if (!repo) return 0;
    return repo.count({
        where
    });
}
async function findUnique(model, id) {
    if (!id) {
        throw new Error(`[DAL] findUnique() llamado sin id para modelo "${model}"`);
    }
    const repo = repoOf(model);
    if (!repo) throw new Error(`[DAL] findUnique(): delegate no encontrado para "${model}"`);
    return repo.findUnique({
        where: {
            id
        }
    });
}
async function create(model, data) {
    const repo = repoOf(model);
    if (!repo) throw new Error(`[DAL] create(): delegate no encontrado para "${model}"`);
    return repo.create({
        data
    });
}
async function update(model, id, data) {
    if (!id) throw new Error(`[DAL] update() llamado sin id para modelo "${model}"`);
    const repo = repoOf(model);
    if (!repo) throw new Error(`[DAL] update(): delegate no encontrado para "${model}"`);
    return repo.update({
        where: {
            id
        },
        data
    });
}
async function remove(model, id) {
    if (!id) throw new Error(`[DAL] remove() llamado sin id para modelo "${model}"`);
    const repo = repoOf(model);
    if (!repo) throw new Error(`[DAL] remove(): delegate no encontrado para "${model}"`);
    return repo.delete({
        where: {
            id
        }
    });
}
async function bulkDelete(model, ids) {
    const repo = repoOf(model);
    if (!repo) throw new Error(`[DAL] bulkDelete(): delegate no encontrado para "${model}"`);
    return repo.deleteMany({
        where: {
            id: {
                in: ids
            }
        }
    });
}
async function existsByField(model, field, value, excludeId) {
    const repo = repoOf(model);
    if (!repo) throw new Error(`[DAL] existsByField(): delegate no encontrado para "${model}"`);
    const where = {
        [field]: value
    };
    if (excludeId) where.NOT = {
        id: excludeId
    };
    const found = await repo.findFirst({
        where,
        select: {
            id: true
        }
    });
    return !!found;
}
}),
"[project]/infrastructure/repositories/prisma-generic-repo.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// infrastructure/repositories/prisma-generic-repo.ts
__turbopack_context__.s([
    "PrismaGenericRepository",
    ()=>PrismaGenericRepository
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/prisma.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$infrastructure$2f$dal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/infrastructure/dal.ts [app-route] (ecmascript)"); // usamos tu mapeo existente
;
;
class PrismaGenericRepository {
    slug;
    delegate;
    key;
    constructor(slug){
        this.slug = slug;
        // keyFor puede estar tipado como string en tu dal.ts -> forzamos el tipo esperado
        const key = (0, __TURBOPACK__imported__module__$5b$project$5d2f$infrastructure$2f$dal$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["keyFor"])(slug);
        const d = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"][key];
        if (!d) {
            throw new Error(`[PrismaGenericRepository] Delegate no encontrado para "${slug}" (key: "${String(key)}")`);
        }
        this.key = key;
        this.delegate = d;
    }
    async list(params) {
        const { where, orderBy, skip, take, select, include } = params || {};
        const [items, total] = await Promise.all([
            this.delegate.findMany({
                where,
                orderBy,
                skip,
                take,
                select,
                include
            }),
            this.delegate.count({
                where
            })
        ]);
        return {
            items,
            total
        };
    }
    async findById(id) {
        if (!id) return null;
        return this.delegate.findUnique({
            where: {
                id
            }
        });
    }
    async create(data) {
        return this.delegate.create({
            data
        });
    }
    async update(id, data) {
        if (!id) throw new Error('[PrismaGenericRepository] update() sin id');
        return this.delegate.update({
            where: {
                id
            },
            data
        });
    }
    async delete(id) {
        if (!id) throw new Error('[PrismaGenericRepository] delete() sin id');
        await this.delegate.delete({
            where: {
                id
            }
        });
    }
    async existsByField(field, value, excludeId) {
        const where = {
            [field]: value
        };
        if (excludeId) where.NOT = {
            id: excludeId
        };
        const found = await this.delegate.findFirst({
            where,
            select: {
                id: true
            }
        });
        return !!found;
    }
}
}),
"[project]/infrastructure/repositories/prisma-dynamic-repo.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// infrastructure/repositories/prisma-dynamic-repo.ts
__turbopack_context__.s([
    "PrismaDynamicRepository",
    ()=>PrismaDynamicRepository
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/prisma.ts [app-route] (ecmascript)");
;
class PrismaDynamicRepository {
    collectionSlug;
    constructor(collectionSlug){
        this.collectionSlug = collectionSlug;
    }
    async collectionOrThrow() {
        const c = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].collection.findUnique({
            where: {
                slug: this.collectionSlug.toLowerCase()
            },
            select: {
                id: true
            }
        });
        if (!c) {
            throw new Error(`[PrismaDynamicRepository] No existe la colección "${this.collectionSlug}"`);
        }
        return c;
    }
    async list(params) {
        const { skip = 0, take = 10 } = params || {};
        const col = await this.collectionOrThrow();
        const where = {
            collectionId: col.id
        };
        // Para dinámicas usamos orden fijo por fecha de creación (más nuevo primero)
        const [rows, total] = await Promise.all([
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].dynamicRecord.findMany({
                where,
                skip,
                take,
                orderBy: {
                    createdAt: 'desc'
                },
                select: {
                    id: true,
                    data: true,
                    createdAt: true,
                    updatedAt: true
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].dynamicRecord.count({
                where
            })
        ]);
        // Aplanamos el JSON de `data` al objeto que espera la tabla
        const items = rows.map((r)=>({
                id: r.id,
                createdAt: r.createdAt,
                updatedAt: r.updatedAt,
                ...r.data ?? {}
            }));
        return {
            items,
            total
        };
    }
    async findById(id) {
        if (!id) return null;
        const r = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].dynamicRecord.findUnique({
            where: {
                id
            },
            select: {
                id: true,
                data: true,
                createdAt: true,
                updatedAt: true
            }
        });
        if (!r) return null;
        return {
            id: r.id,
            createdAt: r.createdAt,
            updatedAt: r.updatedAt,
            ...r.data ?? {}
        };
    }
    async create(data) {
        const col = await this.collectionOrThrow();
        const r = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].dynamicRecord.create({
            data: {
                collectionId: col.id,
                data
            },
            select: {
                id: true,
                data: true,
                createdAt: true,
                updatedAt: true
            }
        });
        return {
            id: r.id,
            createdAt: r.createdAt,
            updatedAt: r.updatedAt,
            ...r.data ?? {}
        };
    }
    async update(id, data) {
        if (!id) throw new Error('[PrismaDynamicRepository] update() sin id');
        const r = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].dynamicRecord.update({
            where: {
                id
            },
            data: {
                data
            },
            select: {
                id: true,
                data: true,
                createdAt: true,
                updatedAt: true
            }
        });
        return {
            id: r.id,
            createdAt: r.createdAt,
            updatedAt: r.updatedAt,
            ...r.data ?? {}
        };
    }
    async delete(id) {
        if (!id) throw new Error('[PrismaDynamicRepository] delete() sin id');
        await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].dynamicRecord.delete({
            where: {
                id
            }
        });
    }
    /**
   * Chequeo de unicidad.
   * En SQLite no hay "JSON path equals", así que hacemos un scan acotado.
   * Para volúmenes grandes/mucho uso de únicos, conviene Postgres.
   */ async existsByField(field, value, excludeId) {
        const col = await this.collectionOrThrow();
        // Escaneo acotado (ajusta 'take' si lo necesitas)
        const sample = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].dynamicRecord.findMany({
            where: {
                collectionId: col.id
            },
            select: {
                id: true,
                data: true
            },
            take: 1000
        });
        return sample.some((r)=>{
            if (excludeId && r.id === excludeId) return false;
            const d = r.data || {};
            return d[field] === value;
        });
    }
}
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[project]/lib/config-loader.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// lib/config-loader.ts
__turbopack_context__.s([
    "getAvailableModels",
    ()=>getAvailableModels,
    "getTableConfig",
    ()=>getTableConfig
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/prisma.ts [app-route] (ecmascript)");
;
;
;
const ROOT = process.cwd();
const CRUD_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(ROOT, "config/crud");
const MODELS_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(ROOT, "config/models");
const CRUD_TABLE_FILE = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(CRUD_DIR, "crudTable.json");
function candidatesFor(model) {
    return [
        __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(MODELS_DIR, `${model}.json`),
        __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(MODELS_DIR, `${model.toLowerCase()}.json`),
        __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(MODELS_DIR, `${model.toLowerCase()}s.json`)
    ];
}
function readModelJson(model) {
    for (const f of candidatesFor(model)){
        try {
            const raw = __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].readFileSync(f, "utf-8");
            return JSON.parse(raw);
        } catch  {}
    }
    return null;
}
function detailsToColumns(details) {
    return (details || []).map((d)=>({
            key: d.key,
            title: d.title || d.key,
            type: d.type || "text",
            sortable: d.sortable ?? true,
            filterable: d.filterable ?? true,
            frozen: d.frozen ?? false,
            required: d.required ?? false,
            hidden: d.hidden ?? false,
            hideable: d.hideable ?? false,
            render: d.render ?? "grid-form",
            options: d.listOptions ? String(d.listOptions).split(",").map((s)=>s.trim()).filter(Boolean) : undefined,
            unique: d.unique ?? false
        }));
}
function adaptSeedToTableConfig(seed) {
    return {
        model: seed.model,
        title: seed.title || seed.model,
        description: seed.description || undefined,
        columns: seed.columns || [],
        rowActions: seed.rowActions || [],
        bulkActions: seed.bulkActions || [],
        enableSelection: true,
        enableMultiSelection: true,
        enablePagination: true,
        pageSize: 20,
        enableSearch: true,
        enableFilters: true,
        enableExport: true
    };
}
async function getTableConfig(modelName) {
    const slug = (modelName || "").trim();
    if (!slug) return null;
    // 1) DB
    const cfg = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].configCrud.findUnique({
        where: {
            model: slug
        },
        include: {
            details: true
        }
    });
    if (cfg) {
        const columns = detailsToColumns(cfg.details || []);
        return {
            model: cfg.model,
            title: cfg.title || cfg.model,
            description: undefined,
            columns,
            rowActions: [],
            bulkActions: [],
            enableSelection: cfg.enableSelection ?? true,
            enableMultiSelection: cfg.enableMultiSelection ?? true,
            enablePagination: cfg.enablePagination ?? true,
            pageSize: cfg.pageSize ?? 20,
            enableSearch: cfg.enableSearch ?? true,
            searchPlaceholder: cfg.searchPlaceHolder ?? "Search...",
            enableFilters: cfg.enableFilters ?? true,
            enableExport: cfg.enableExport ?? true
        };
    }
    // 2) Fallback JSON
    const seed = readModelJson(slug);
    if (seed) return adaptSeedToTableConfig(seed);
    // 3) Nada
    return null;
}
async function getAvailableModels() {
    try {
        const raw = __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].readFileSync(CRUD_TABLE_FILE, "utf-8");
        const json = JSON.parse(raw);
        return Array.isArray(json?.models) ? json.models.map((m)=>m.name) : [];
    } catch  {
        return [];
    }
}
}),
"[project]/application/usecases/records.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// application/usecases/records.ts
__turbopack_context__.s([
    "makeRecordUseCases",
    ()=>makeRecordUseCases
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2d$loader$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/config-loader.ts [app-route] (ecmascript)");
;
/**
 * Construye el "where" de búsqueda a partir del JSON de la tabla (campos filterable).
 * Evitamos 'mode: insensitive' para compatibilidad con SQLite.
 */ function buildSearchWhere(cfg, search) {
    if (!cfg || !search) return undefined;
    const filterable = cfg.columns.filter((c)=>c.filterable).map((c)=>({
            key: c.key,
            type: c.type
        }));
    if (filterable.length === 0) return undefined;
    const or = [];
    const n = Number(search);
    const isNumeric = Number.isFinite(n);
    for (const f of filterable){
        // si el campo es numérico, permitimos buscar por igualdad
        if (isNumeric && (f.type === "number" || f.type === "currency")) {
            or.push({
                [f.key]: n
            });
        } else {
            or.push({
                [f.key]: {
                    contains: search
                }
            });
        }
    }
    if (or.length === 0) return undefined;
    return {
        OR: or
    };
}
/**
 * Ordenación segura
 */ function buildOrderBy(cfg, sortBy, sortOrder) {
    const field = sortBy && cfg?.columns.some((c)=>c.key === sortBy) ? sortBy : "createdAt";
    const dir = sortOrder === "asc" ? "asc" : "desc";
    return {
        [field]: dir
    };
}
class ConflictError extends Error {
    status = 409;
    constructor(message){
        super(message);
        this.name = "ConflictError";
    }
}
function makeRecordUseCases(repo, slug) {
    return {
        async list (params) {
            const { page = 1, pageSize = 20, search = "", sortBy, sortOrder } = params;
            const cfg = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2d$loader$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getTableConfig"])(slug);
            const where = buildSearchWhere(cfg, search);
            const orderBy = buildOrderBy(cfg, sortBy, sortOrder);
            const skip = (page - 1) * pageSize;
            const take = pageSize;
            const { items, total } = await repo.list({
                where,
                orderBy,
                skip,
                take
            });
            return {
                data: items,
                total,
                page,
                pageSize
            };
        },
        async get (id) {
            return repo.findById(id);
        },
        async create (data) {
            const cfg = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2d$loader$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getTableConfig"])(slug);
            if (cfg) {
                for (const col of cfg.columns.filter((c)=>c.unique)){
                    const value = data?.[col.key];
                    if (value !== undefined && value !== null && value !== "") {
                        const exists = await repo.existsByField(col.key, value);
                        if (exists) {
                            throw new ConflictError(`${col.title || col.key} ya está en uso`);
                        }
                    }
                }
            }
            return repo.create(data);
        },
        async update (id, data) {
            const cfg = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2d$loader$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getTableConfig"])(slug);
            if (cfg) {
                for (const col of cfg.columns.filter((c)=>c.unique)){
                    const value = data?.[col.key];
                    if (value !== undefined && value !== null && value !== "") {
                        const exists = await repo.existsByField(col.key, value, id);
                        if (exists) {
                            throw new ConflictError(`${col.title || col.key} ya está en uso`);
                        }
                    }
                }
            }
            return repo.update(id, data);
        },
        async remove (id) {
            await repo.delete(id);
            return {
                id,
                deleted: true
            };
        },
        async existsByField (field, value, excludeId) {
            return repo.existsByField(field, value, excludeId);
        }
    };
}
}),
"[project]/lib/di.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// lib/di.ts
__turbopack_context__.s([
    "getUseCasesFor",
    ()=>getUseCasesFor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$infrastructure$2f$repositories$2f$prisma$2d$generic$2d$repo$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/infrastructure/repositories/prisma-generic-repo.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$infrastructure$2f$repositories$2f$prisma$2d$dynamic$2d$repo$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/infrastructure/repositories/prisma-dynamic-repo.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$application$2f$usecases$2f$records$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/application/usecases/records.ts [app-route] (ecmascript)");
;
;
;
function getUseCasesFor(slug) {
    const s = (slug || '').toLowerCase();
    try {
        const repo = new __TURBOPACK__imported__module__$5b$project$5d2f$infrastructure$2f$repositories$2f$prisma$2d$generic$2d$repo$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["PrismaGenericRepository"](s);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$application$2f$usecases$2f$records$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["makeRecordUseCases"])(repo, s);
    } catch  {
        const repo = new __TURBOPACK__imported__module__$5b$project$5d2f$infrastructure$2f$repositories$2f$prisma$2d$dynamic$2d$repo$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["PrismaDynamicRepository"](s);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$application$2f$usecases$2f$records$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["makeRecordUseCases"])(repo, s);
    }
}
}),
"[project]/app/api/crud/[model]/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// app/api/crud/[model]/route.ts
__turbopack_context__.s([
    "GET",
    ()=>GET,
    "POST",
    ()=>POST,
    "runtime",
    ()=>runtime
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/prisma.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$di$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/di.ts [app-route] (ecmascript)");
const runtime = "nodejs";
;
;
;
function toClientKey(m) {
    return m.slice(0, 1).toLowerCase() + m.slice(1);
}
async function GET(req, { params }) {
    const { model } = params;
    const url = new URL(req.url);
    const take = Number(url.searchParams.get("take") || 50);
    const skip = Number(url.searchParams.get("skip") || 0);
    try {
        const key = toClientKey(model);
        const delegate = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"][key];
        if (!delegate?.findMany) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: "model_not_found"
            }, {
                status: 400
            });
        }
        const data = await delegate.findMany({
            skip,
            take,
            orderBy: {
                createdAt: "desc"
            }
        });
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            data
        });
    } catch (e) {
        console.error("[crud list] error", e);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "list_failed"
        }, {
            status: 500
        });
    }
}
async function POST(req, { params }) {
    const { model } = params;
    try {
        const body = await req.json();
        const uc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$di$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getUseCasesFor"])(model);
        const created = await uc.create(body);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            data: created
        });
    } catch (e) {
        if (e?.status === 409) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: e.message || "conflict"
            }, {
                status: 409
            });
        }
        console.error("[crud create] error", e);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "create_failed"
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__8c4b9255._.js.map