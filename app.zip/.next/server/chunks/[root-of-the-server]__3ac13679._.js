module.exports = [
"[project]/.next-internal/server/app/api/config-crud/tables/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/fs/promises [external] (fs/promises, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs/promises", () => require("fs/promises"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[project]/app/api/config-crud/tables/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// app/api/config-crud/tables/route.ts
__turbopack_context__.s([
    "GET",
    ()=>GET,
    "POST",
    ()=>POST,
    "dynamic",
    ()=>dynamic,
    "runtime",
    ()=>runtime
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs$2f$promises__$5b$external$5d$__$28$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs/promises [external] (fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
;
;
;
;
const runtime = 'nodejs';
const dynamic = 'force-dynamic';
const ROOT = process.cwd();
const SCHEMA = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].resolve(ROOT, 'prisma/schema.prisma');
const MODELS_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].resolve(ROOT, 'config/models');
const OUT_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].resolve(ROOT, 'config/crud');
const OUT_TABLES = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(OUT_DIR, 'configTables.json');
const OUT_DETAIL = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(OUT_DIR, 'configTableDetail.json');
async function ensureDirAndFiles() {
    if (!__TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].existsSync(OUT_DIR)) await __TURBOPACK__imported__module__$5b$externals$5d2f$fs$2f$promises__$5b$external$5d$__$28$fs$2f$promises$2c$__cjs$29$__["default"].mkdir(OUT_DIR, {
        recursive: true
    });
    if (!__TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].existsSync(OUT_TABLES)) await __TURBOPACK__imported__module__$5b$externals$5d2f$fs$2f$promises__$5b$external$5d$__$28$fs$2f$promises$2c$__cjs$29$__["default"].writeFile(OUT_TABLES, JSON.stringify({
        models: []
    }, null, 2));
    if (!__TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].existsSync(OUT_DETAIL)) await __TURBOPACK__imported__module__$5b$externals$5d2f$fs$2f$promises__$5b$external$5d$__$28$fs$2f$promises$2c$__cjs$29$__["default"].writeFile(OUT_DETAIL, JSON.stringify({}, null, 2));
}
async function loadJson(file, fallback) {
    try {
        const raw = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs$2f$promises__$5b$external$5d$__$28$fs$2f$promises$2c$__cjs$29$__["default"].readFile(file, 'utf-8');
        return raw ? JSON.parse(raw) : fallback;
    } catch  {
        return fallback;
    }
}
function parseKeyValueList(str) {
    const out = {};
    for (const pair of String(str || '').split(',')){
        const [k, v] = pair.split(':').map((s)=>s?.trim());
        if (!k) continue;
        if (v) out[k] = v.replace(/^['"]|['"]$/g, '');
    }
    return out;
}
function toTitle(s) {
    if (!s) return s;
    return s.charAt(0).toUpperCase() + s.slice(1);
}
async function readAllModelJsons() {
    if (!__TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].existsSync(MODELS_DIR)) return [];
    const files = (await __TURBOPACK__imported__module__$5b$externals$5d2f$fs$2f$promises__$5b$external$5d$__$28$fs$2f$promises$2c$__cjs$29$__["default"].readdir(MODELS_DIR)).filter((f)=>f.endsWith('.json'));
    const out = [];
    for (const f of files){
        try {
            const obj = JSON.parse(await __TURBOPACK__imported__module__$5b$externals$5d2f$fs$2f$promises__$5b$external$5d$__$28$fs$2f$promises$2c$__cjs$29$__["default"].readFile(__TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(MODELS_DIR, f), 'utf-8'));
            if (obj?.model) out.push(obj);
        } catch  {}
    }
    return out;
}
function discoverCrudModels(schemaText) {
    const models = [];
    const lines = schemaText.split('\n');
    for(let i = 0; i < lines.length; i++){
        const line = lines[i].trim();
        if (line.startsWith('model ')) {
            const m = /^model\s+(\w+)\s*\{/.exec(line);
            if (!m) continue;
            const modelName = m[1];
            const window = lines.slice(Math.max(0, i - 5), i).join('\n');
            const crudLine = /\/\/\/\s*@crud(?:\(([^)]*)\))?/i.exec(window);
            const hasCrudDoc = !!crudLine;
            const hasPrefix = /^Crud/i.test(modelName) // opcional
            ;
            if (hasCrudDoc || hasPrefix) {
                const meta = crudLine?.[1] ? parseKeyValueList(crudLine[1]) : {};
                models.push({
                    name: modelName,
                    meta
                });
            }
        }
    }
    return models;
}
function parseModelFields(schemaText, model) {
    const re = new RegExp(`model\\s+${model}\\s*\\{([\\s\\S]*?)\\}`, 'm');
    const m = re.exec(schemaText);
    if (!m) return [];
    return m[1].split('\n').map((s)=>s.trim()).filter((s)=>s && !s.startsWith('//') && !s.startsWith('@@')).map((line)=>{
        const [name, type, ...rest] = line.split(/\s+/);
        return {
            name,
            type,
            raw: rest.join(' ')
        };
    });
}
function toColumnConfig(field) {
    const k = field.name;
    const t = field.type.replace('?', '');
    const base = {
        key: k,
        title: toTitle(k),
        sortable: true,
        filterable: true,
        type: 'text'
    };
    if ([
        'Int',
        'BigInt',
        'Float',
        'Decimal'
    ].includes(t)) return {
        ...base,
        type: 'number'
    };
    if (t === 'Boolean') return {
        ...base,
        type: 'boolean'
    };
    if (t === 'DateTime') return {
        ...base,
        type: 'date'
    };
    if (/Email/i.test(k)) return {
        ...base,
        type: 'email'
    };
    return base;
}
function pickStatus(meta, fromJson) {
    const allowed = [
        'parametrized',
        'inactive',
        'unset'
    ];
    const fromMeta = typeof meta?.status === 'string' && allowed.includes(meta.status) ? meta.status : undefined;
    const fromCfg = typeof fromJson?.status === 'string' && allowed.includes(fromJson.status) ? fromJson.status : undefined;
    return fromMeta || fromCfg || 'unset';
}
async function generateConfigsInline() {
    const schemaText = await __TURBOPACK__imported__module__$5b$externals$5d2f$fs$2f$promises__$5b$external$5d$__$28$fs$2f$promises$2c$__cjs$29$__["default"].readFile(SCHEMA, 'utf-8');
    const discovered = discoverCrudModels(schemaText) // [{ name, meta }]
    ;
    await ensureDirAndFiles();
    const modelJsons = await readAllModelJsons();
    const jsonByModel = new Map(modelJsons.map((j)=>[
            String(j.model),
            j
        ]));
    // Índice
    const tables = await loadJson(OUT_TABLES, {
        models: []
    });
    const indexByModel = new Map(tables.models.map((m, i)=>[
            m.model,
            i
        ]));
    for (const { name, meta } of discovered){
        const fromJson = jsonByModel.get(name) || {};
        const status = pickStatus(meta, fromJson);
        if (indexByModel.has(name)) {
            const idx = indexByModel.get(name);
            tables.models[idx].status = status;
            if (fromJson?.title) tables.models[idx].title = fromJson.title;
        } else {
            tables.models.push({
                model: name,
                title: fromJson?.title || name,
                status
            });
            indexByModel.set(name, tables.models.length - 1);
        }
    }
    await __TURBOPACK__imported__module__$5b$externals$5d2f$fs$2f$promises__$5b$external$5d$__$28$fs$2f$promises$2c$__cjs$29$__["default"].writeFile(OUT_TABLES, JSON.stringify(tables, null, 2));
    // Detalle
    const detail = await loadJson(OUT_DETAIL, {});
    for (const { name, meta } of discovered){
        const fromJson = jsonByModel.get(name) || {};
        const status = pickStatus(meta, fromJson);
        if (!detail[name]) {
            const fields = parseModelFields(schemaText, name);
            const columnsHeur = fields.filter((f)=>![
                    'id',
                    'createdAt',
                    'updatedAt'
                ].includes(f.name)).map(toColumnConfig);
            detail[name] = {
                model: name,
                title: fromJson?.title || name,
                description: fromJson?.description || undefined,
                status,
                columns: Array.isArray(fromJson?.columns) && fromJson.columns.length > 0 ? fromJson.columns : columnsHeur,
                rowActions: Array.isArray(fromJson?.rowActions) ? fromJson.rowActions : [
                    {
                        id: 'edit',
                        label: 'Editar',
                        icon: 'pencil',
                        variant: 'ghost',
                        action: 'edit'
                    }
                ],
                bulkActions: Array.isArray(fromJson?.bulkActions) ? fromJson.bulkActions : [
                    {
                        id: 'export',
                        label: 'Exportar CSV',
                        icon: 'download',
                        variant: 'outline',
                        action: 'export'
                    }
                ],
                relations: Array.isArray(fromJson?.relations) ? fromJson.relations : undefined,
                containerId: fromJson?.containerId || undefined
            };
        } else {
            detail[name].status = status; // sincroniza estado
        }
    }
    await __TURBOPACK__imported__module__$5b$externals$5d2f$fs$2f$promises__$5b$external$5d$__$28$fs$2f$promises$2c$__cjs$29$__["default"].writeFile(OUT_DETAIL, JSON.stringify(detail, null, 2));
    return {
        tables,
        detail
    };
}
async function GET() {
    try {
        await ensureDirAndFiles();
        const tables = await loadJson(OUT_TABLES, {
            models: []
        });
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(tables, {
            headers: {
                'Cache-Control': 'no-store'
            }
        });
    } catch (e) {
        console.error('[config-crud/tables] GET error', e);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            models: []
        }, {
            status: 200
        });
    }
}
async function POST() {
    try {
        const result = await generateConfigsInline();
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            ok: true,
            models: result.tables.models
        }, {
            headers: {
                'Cache-Control': 'no-store'
            }
        });
    } catch (e) {
        console.error('[config-crud/tables] POST error', e);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: e?.message || 'failed_to_generate'
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__3ac13679._.js.map