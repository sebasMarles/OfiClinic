var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/config-crud/[model]/keys/route.js")
R.c("server/chunks/node_modules_next_2c64efa4._.js")
R.c("server/chunks/[root-of-the-server]__eac1d183._.js")
R.m("[project]/.next-internal/server/app/api/config-crud/[model]/keys/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/config-crud/[model]/keys/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/config-crud/[model]/keys/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
