var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/config-crud/[model]/route.js")
R.c("server/chunks/node_modules_next_0dc1241d._.js")
R.c("server/chunks/[root-of-the-server]__5d674ace._.js")
R.m("[project]/.next-internal/server/app/api/config-crud/[model]/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/config-crud/[model]/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/config-crud/[model]/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
