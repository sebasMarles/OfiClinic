var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/tables/route.js")
R.c("server/chunks/node_modules_next_68be2122._.js")
R.c("server/chunks/[root-of-the-server]__62d228e2._.js")
R.m("[project]/.next-internal/server/app/api/tables/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/tables/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/tables/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
