(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_globals_71f961d1.css",
  "static/chunks/node_modules_d127445b._.js",
  "static/chunks/_07205f43._.js"
],
    source: "dynamic"
});
