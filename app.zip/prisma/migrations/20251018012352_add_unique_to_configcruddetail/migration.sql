-- AlterTable
ALTER TABLE "ConfigCrudDetail" ADD COLUMN     "unique" BOOLEAN DEFAULT false;
